int asm_main( void );

int main()
{
  int ret_status;
  ret_status = asm_main();
  return ret_status;
}
